chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'getRedirectURL') {
    sendResponse({ url: chrome.identity.getRedirectURL('callback') });
    return true;
  }
});

# Privacy Policy for Musical

**Last updated: January 24, 2026**

## Overview
Musical is a Chrome extension that allows users to play music from SoundCloud. This privacy policy explains how we handle user data.

## Data Collection
Musical collects and stores **only** your SoundCloud authentication token. This token is:
- Stored locally on your device using Chrome's storage API
- Used solely to authenticate with SoundCloud's API for music playback
- Never transmitted to any third-party servers

## Data We Do NOT Collect
- Personal information (name, email, etc.)
- Browsing history
- Location data
- Financial information
- Any other personal data

## Third-Party Services
This extension connects to SoundCloud's API to provide music playback functionality. Your use of SoundCloud through this extension is subject to [SoundCloud's Privacy Policy](https://soundcloud.com/pages/privacy).

## Data Storage
All data is stored locally on your device. You can clear this data at any time by:
- Logging out of the extension
- Removing the extension from Chrome

## Changes to This Policy
We may update this privacy policy from time to time. Any changes will be reflected in the "Last updated" date.

## Contact
If you have questions about this privacy policy, please open an issue on the extension's GitHub repository.

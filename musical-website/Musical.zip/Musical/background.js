chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });

// Offscreen management
const OFFSCREEN_PATH = 'offscreen.html';

async function createOffscreenDocument() {
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
    documentUrls: [chrome.runtime.getURL(OFFSCREEN_PATH)]
  });

  if (existingContexts.length > 0) {
    return;
  }

  await chrome.offscreen.createDocument({
    url: OFFSCREEN_PATH,
    reasons: ['AUDIO_PLAYBACK'],
    justification: 'Playing music in the background'
  });
}

// Create offscreen document on install/startup
chrome.runtime.onInstalled.addListener(createOffscreenDocument);
chrome.runtime.onStartup.addListener(createOffscreenDocument);

// Message handling
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'getRedirectURL') {
    sendResponse({ url: chrome.identity.getRedirectURL('callback') });
    return true;
  }

  // Ensure offscreen document exists when messages are sent to it
  if (message.target === 'offscreen') {
    createOffscreenDocument().then(() => {
      // Forward message to offscreen document? 
      // Actually, chrome.runtime.sendMessage broadcasts to all frames, 
      // so offscreen.js will pick it up automatically if it's listening.
      // We just need to make sure it's created.
    });
  }
});

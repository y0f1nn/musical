// Offscreen player script
let widget = null;
let isPlaying = false;
let widgetDuration = 0;
let currentTrack = null;

// Initialize Widget
function initWidget() {
    const iframe = document.getElementById('scWidget');
    if (typeof SC !== 'undefined' && SC.Widget) {
        widget = SC.Widget(iframe);
        bindEvents();
        console.log('[Offscreen] Widget initialized');
    } else {
        console.error('[Offscreen] SC Widget API not loaded');
        // Retry if script hasn't loaded yet
        setTimeout(initWidget, 1000);
    }
}

function bindEvents() {
    widget.bind(SC.Widget.Events.READY, () => {
        console.log('[Offscreen] Widget Ready');
        broadcastStatus();
    });

    widget.bind(SC.Widget.Events.PLAY, () => {
        isPlaying = true;
        broadcastStatus();
    });

    widget.bind(SC.Widget.Events.PAUSE, () => {
        isPlaying = false;
        broadcastStatus();
    });

    widget.bind(SC.Widget.Events.FINISH, () => {
        isPlaying = false;
        // Notify that track finished - maybe let side panel handle next track logic
        // or handle queue here? For now, let's just broadcast status.
        // Ideally, side panel logic for queues should move here or background, 
        // but for this refactor, we'll keep it simple: side panel observes finish and triggers next.
        broadcastEvent('FINISH');
        broadcastStatus();
    });

    widget.bind(SC.Widget.Events.PLAY_PROGRESS, (data) => {
        // Broadcast progress frequently
        broadcastStatus(data.currentPosition);
    });
}

function broadcastStatus(currentPosition = null) {
    if (!widget) return;
    
    // We can't get all data synchronously from widget, so we rely on cached state + what we know
    // Ideally we request duration if we don't have it
    if (widgetDuration === 0) {
        widget.getDuration((d) => {
            widgetDuration = d;
            sendStatus(currentPosition);
        });
    } else {
        sendStatus(currentPosition);
    }
}

function sendStatus(currentPosition) {
    chrome.runtime.sendMessage({
        type: 'PLAYBACK_STATUS',
        payload: {
            isPlaying: isPlaying,
            currentPosition: currentPosition,
            duration: widgetDuration,
            track: currentTrack
        }
    });
}

function broadcastEvent(eventName) {
    chrome.runtime.sendMessage({
        type: 'PLAYER_EVENT',
        eventName: eventName
    });
}

// Handle Messages
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.target !== 'offscreen') return;

    console.log('[Offscreen] Received message:', message);

    if (!widget) {
        console.warn('[Offscreen] Widget not ready');
        return;
    }

    switch (message.action) {
        case 'LOAD':
            if (message.payload && message.payload.url) {
                currentTrack = message.payload.track; // Store track metadata if provided
                widget.load(message.payload.url, {
                    auto_play: true,
                    show_artwork: false,
                    callback: () => {
                        widget.getDuration(d => {
                            widgetDuration = d;
                            isPlaying = true; // Auto play is sets
                            broadcastStatus();
                        });
                    }
                });
            }
            break;
            
        case 'PLAY':
            widget.play();
            break;
            
        case 'PAUSE':
            widget.pause();
            break;
            
        case 'TOGGLE':
            widget.toggle();
            break;
            
        case 'SEEK':
            if (message.payload && message.payload.time) {
                widget.seekTo(message.payload.time);
            }
            break;
            
        case 'SET_VOLUME':
            if (message.payload && message.payload.volume) {
                widget.setVolume(message.payload.volume);
            }
            break;

        case 'GET_STATUS':
             // Force a status update
             widget.getPosition((pos) => {
                 broadcastStatus(pos);
             });
             break;
    }
});

// Start
document.addEventListener('DOMContentLoaded', initWidget);
